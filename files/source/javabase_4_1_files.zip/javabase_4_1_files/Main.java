package com.akoval;

public class Main {
    public static void main(String[] args) {
        Point3D point1 = new Point3D();
        Point3D point2 = new Point3D(5,6,7);

        System.out.println(point1.getX());
        System.out.println(point1.getY());

        System.out.println(point2.getX());
        System.out.println(point2.getY());
        System.out.println(point2.getZ());

        point1.moveTo(44,55);
        System.out.println(point1.getX());
        System.out.println(point1.getY());

        System.out.println(point2.distance(1,1,1));
        System.out.println(point2.distance());

        Point2D p = point2;
        System.out.println(p.getX());
        System.out.println(p.getY());
        System.out.println(p.distance());

        Point3D p3 = new Point3D(1,2,3);
        System.out.println(point2.equals(p3));

    }
}