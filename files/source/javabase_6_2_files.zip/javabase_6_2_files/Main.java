package com.akoval;

public class Main {

    public static void f(int denom, String str) {
        try {
            int result = 123 / denom;
            str.length();
        } catch(ArithmeticException exc) {
            System.out.println("Exception is here in method f: " + exc.getMessage());
            //exc.printStackTrace();
        }

    }
    public static void main(String[] args) {
        try {
            f(0, "test");
            f(20, null);
        } catch (NullPointerException exc) {
            System.out.println("Exception is here in method main: " + exc.getMessage());
            //exc.printStackTrace();
        }
        System.out.println("Hi");
    }
}