package com.akoval;

public class MethodFException extends Exception {
    public MethodFException() {
    }

    public MethodFException(String message) {
        super(message);
    }

    public MethodFException(String message, Throwable cause) {
        super(message, cause);
    }

    public MethodFException(Throwable cause) {
        super(cause);
    }
}
