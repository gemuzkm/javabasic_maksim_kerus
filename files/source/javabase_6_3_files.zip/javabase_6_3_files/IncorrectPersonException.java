package com.akoval;

public class IncorrectPersonException extends Exception {

    public IncorrectPersonException(ErrorCode code, String param) {
        super(String.format(code.getMessageTemplate(), param));
    }
}
