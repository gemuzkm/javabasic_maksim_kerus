package com.akoval;

public class Person {
    private String firstname;
    private String lastname;
    private int year;

    public Person(String firstname, String lastname, int year) throws IncorrectPersonException {
        this.setFirstname(firstname);
        this.setLastname(lastname);
        this.setYear(year);
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) throws IncorrectPersonException {
        if(firstname == null || firstname.length() <= 1) {
            throw new IncorrectPersonException(ErrorCode.WRONG_FIRSTNAME, firstname);
        }
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) throws IncorrectPersonException {
        if(lastname == null || lastname.length() <= 1) {
            throw new IncorrectPersonException(ErrorCode.WRONG_LASTNAME, lastname);
        }
        this.lastname = lastname;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) throws IncorrectPersonException {
        if(year > 0) {
            throw new IncorrectPersonException(ErrorCode.WRONG_YEAR, Integer.toString(year));
        }
        this.year = year;
    }
}
