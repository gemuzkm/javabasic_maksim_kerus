package com.akoval;

public enum ErrorCode {
    WRONG_LASTNAME("lastname is incorrect: current value is %s"),
    WRONG_FIRSTNAME("firstname is incorrect: current value is %s"),
    WRONG_YEAR("year must be positive: current value is %s");

    private String messageTemplate;

    ErrorCode(String message) {
        this.messageTemplate = message;
    }

    public String getMessageTemplate() {
        return messageTemplate;
    }
}
