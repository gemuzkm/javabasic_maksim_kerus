package com.akoval;

public class Main {
    public static void createPerson(String firstname, String lastname, int year) {
        try {
            Person p = new Person(firstname, lastname, year);
            System.out.println("Person is created");
        } catch(Exception exc) {
            System.out.println("Cannot create person");
            exc.printStackTrace();
        } finally {
            System.out.println("This is final code!!!");
        }
    }
    public static void main(String[] args) {
        createPerson(null, "koval", 1987);
        createPerson("anton", null, 1987);
        createPerson("anton", "koval", 1987);
        createPerson("anton", "koval", 0);
        createPerson("anton", "koval", -100);
        createPerson("a", "koval", 1987);
        createPerson("anton", "k", 1987);

        try {
            f(0, "");
        } catch (MethodFException| NullPointerException|ArithmeticException exc) {
            exc.printStackTrace();
        }
    }

    public static void f(int denom, String str) throws MethodFException {
        try {
            int result = 123 / denom;
            str.length();
        } catch (NullPointerException|ArithmeticException exc) {
            throw new MethodFException("Method f is failed", exc);
        }
    }

    public boolean check(int a, int b) {
        return a>b;  
    }
}