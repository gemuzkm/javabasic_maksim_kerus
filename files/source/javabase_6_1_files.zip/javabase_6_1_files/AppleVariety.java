package com.akoval.fruits;

public enum AppleVariety implements Colored {
    RED {
        @Override
        public String getSeason() {
            return "summer";
        }

        @Override
        public int getColor() {
            return 5;
        }
    }, GALA {
        @Override
        public String getSeason() {
            return "spring";
        }

        @Override
        public int getColor() {
            return 2;
        }
    }, GRANNY_SMITH {
        @Override
        public String getSeason() {
            return "winter";
        }

        @Override
        public int getColor() {
            return 3;
        }
    }, GOLDEN {
        @Override
        public String getSeason() {
            return "spring";
        }

        @Override
        public int getColor() {
            return 4;
        }
    };

    public abstract String getSeason();
}
