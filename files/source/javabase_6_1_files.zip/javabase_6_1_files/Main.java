package com.akoval;

import com.akoval.fruits.AppleVariety;
import com.akoval.fruits.Colored;

public class Main {
    public static void main(String[] args) {
        AppleVariety var1 = AppleVariety.RED;
        System.out.println(var1.toString());

        if(var1 == AppleVariety.RED) {
            System.out.println("They are equal.");
        }

        switch(var1) {
            case RED:
                System.out.println("This is red");
                break;
            case GOLDEN:
                System.out.println("This is golden");
                break;
            default:
                System.out.println("We don't know");
                break;
        }

        System.out.println(var1.ordinal());
        System.out.println(AppleVariety.RED.compareTo(AppleVariety.GRANNY_SMITH));
        System.out.println(AppleVariety.GRANNY_SMITH.compareTo(AppleVariety.RED));
        System.out.println(AppleVariety.RED.compareTo(AppleVariety.RED));

        System.out.println(AppleVariety.valueOf("RED"));
        //System.out.println(AppleVariery.valueOf("Crisp"));

        System.out.println(var1.getSeason());
        System.out.println(var1.getColor());
        Colored color = AppleVariety.GOLDEN;
        System.out.println(color.getColor());
    }
}