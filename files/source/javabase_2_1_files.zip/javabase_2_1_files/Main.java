package com.akoval;

public class Main {
    public static void main(String[] args) {
        Point2D point1 = new Point2D(20,30);
        System.out.println("X coordinate:" + point1.getX());
        System.out.println("Y coordinate:" + point1.getY());

    }
}