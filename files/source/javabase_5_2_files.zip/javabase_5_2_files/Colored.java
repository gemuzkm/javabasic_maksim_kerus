package com.akoval.fruits;

public interface Colored {
    int getColor();
}
