package com.akoval;

import com.akoval.fruits.Apple;
import com.akoval.fruits.Colored;
import com.akoval.fruits.Fruit;
import com.akoval.fruits.FruitVariety;
import com.akoval.fruits.Orange;

public class Main {
    public static void main(String[] args) {
        Apple apple = new Apple(100, 200, 123);
        System.out.println(apple.getColor());
        System.out.println(FruitVariety.getAvailableVarieties());
        for(String elem:FruitVariety.getAvailableVarieties()) {
            System.out.println(elem);
        }

        Colored colored = apple;
        System.out.println(colored.getColor());

        FruitVariety fr = apple;
        System.out.println(fr.getVariety());
        apple.setVariety(null);
        System.out.println(fr.getVariety());
    }
}