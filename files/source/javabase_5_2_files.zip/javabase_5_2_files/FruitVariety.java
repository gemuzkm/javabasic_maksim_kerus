package com.akoval.fruits;

public interface FruitVariety {
    static String[] getAvailableVarieties() {
        return new String[] { "gala", "granny Smith", "golden"};
    }
    default String getVariety() {
        return "golden";
    }
}
