package com.akoval.fruits;

public final class Apple extends Fruit implements Colored, FruitVariety, SecondFruitVariety {
    private int color;
    private String variety;

    public Apple(double weight, double volume, int color) {
        super(weight, volume);
        this.color = color;
        this.variety = "gala";
    }

    @Override
    public int getTaste() {
        return 6;
    }

    @Override
    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }


    public void setVariety(String variety) {
        this.variety = variety;
    }

    public static boolean testMe() {
        return true;
    }

    @Override
    public String getVariety() {
        if(variety == null) {
            return SecondFruitVariety.super.getVariety();
        }
        return variety;
    }
}
