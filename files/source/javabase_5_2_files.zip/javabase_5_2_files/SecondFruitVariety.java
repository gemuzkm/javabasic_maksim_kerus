package com.akoval.fruits;

public interface SecondFruitVariety {
    static String[] getAvailableVarieties() {
        return new String[] { "gala", "granny Smith", "golden"};
    }
    default String getVariety() {
        return "red";
    }
}
