package com.akoval;

public class Main {
    public static void main(String[] args) {
        Point2D point1 = new Point2D();
        System.out.println("X coordinate:" + point1.getX());
        System.out.println("Y coordinate:" + point1.getY());

        point1.moveTo(10,15);

        System.out.println("X coordinate:" + point1.getX());
        System.out.println("Y coordinate:" + point1.getY());

        Point2D point2 = new Point2D(10, 15);

        System.out.println(point1 == point2);
        System.out.println(point1.equals(point2));

        System.out.println(point1.distance());
        System.out.println(point1.distance(point2.getX(), point2.getY()));
        int x = 100;
        int y = 150;
        point1.changeXY(x, y);
        Point2D point3 = new Point2D(x, y);
        point2.changePoint(point3);
        System.out.println(point3.getX() + " " + point3.getY());

        Factorial f = new Factorial();
        System.out.println(f.fact(5));

        int[] arr = new int[10];
        System.out.println(arr.length);

        for (int i = arr.length - 1;i >= 0;i--) {
            arr[i] = 2;
            if(i == 5) {
                arr[i] = 0;
            }
        }

        for(int tmp: arr) {
            System.out.println(tmp);
        }
    }
}