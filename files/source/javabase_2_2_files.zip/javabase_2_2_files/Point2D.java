package com.akoval;

public class Point2D {
    private int x = 1, y = 2;

    public Point2D() {
        this(50, 55);
    }

    public Point2D(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void moveTo(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public double distance(int x, int y) {
        return Math.sqrt((this.x - x)* (this.x - x) + (this.y - y) * (this.y - y));
    }

    public double distance() {
        return Math.sqrt((this.x)* (this.x) + (this.y) * (this.y));
    }

    public void changeXY(int x, int y) {
        x = 0;
        y = 0;
    }

    public void changePoint(Point2D p) {
        p.setX(0);
        p.setY(0);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Point2D point2D = (Point2D) o;

        if (x != point2D.x) return false;
        return y == point2D.y;
    }

    @Override
    public int hashCode() {
        int result = x;
        result = 31 * result + y;
        return result;
    }
}
