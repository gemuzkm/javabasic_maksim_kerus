package com.akoval;

public class RacingStatistics {
    public double getAvgLapSpeed(double lapLength, double time, boolean hasPitStop) {
        if(time == 0) {
            return 0;
        }

        if(hasPitStop) {
            return lapLength/(time-20);
        }
        return lapLength/time;
    }
}
