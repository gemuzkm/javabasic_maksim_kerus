package com.akoval;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class RacingStatisticsTest {

    @Test
    void getAvgLapSpeed() {
        RacingStatistics stats = new RacingStatistics();
        assertEquals(10, stats.getAvgLapSpeed(1000, 100, false), 0.000001);
    }

    @Test
    void getAvgLapSpeedWithZeroTime() {
        RacingStatistics stats = new RacingStatistics();
        assertEquals(10, stats.getAvgLapSpeed(1000, 0, false), 0.000001);
    }
    
    @Test
    void getAvgLapSpeedWithPitStop() {
        RacingStatistics stats = new RacingStatistics();
        assertEquals(10, stats.getAvgLapSpeed(1000, 120, true), 0.000001);
    }
}