package com.akoval;

import com.akoval.fruits.Apple;
import com.akoval.fruits.Fruit;
import com.akoval.fruits.Orange;

public class Main {
    public static void main(String[] args) {
        Parallelepiped par = new Parallelepiped(10,10,10);
        System.out.println(par.getVolume());

        int volume = new Point3D(10,10,10) {
            int getVolume() {
                return getX()*getY()*getZ();
            }
        }.getVolume();
        System.out.println(volume);
    }
}