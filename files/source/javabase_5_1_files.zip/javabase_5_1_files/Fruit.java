package com.akoval.fruits;

public abstract class Fruit {
    private final double weight;
    private final double volume;

    public Fruit(double weight, double volume) {
        this.weight = weight;
        this.volume = volume;
    }

    public final double getWeight() {
        return weight;
    }

    public double getVolume() {
        return volume;
    }

    public abstract int getTaste();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Fruit fruit = (Fruit) o;

        if (Double.compare(fruit.weight, weight) != 0) return false;
        return Double.compare(fruit.volume, volume) == 0;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        temp = Double.doubleToLongBits(weight);
        result = (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(volume);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
}
