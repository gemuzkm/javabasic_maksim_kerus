package com.akoval.fruits;

public class Orange extends Fruit {
    public Orange(double weight, double volume) {
        super(weight, volume);
    }

    @Override
    public int getTaste() {
        return 8;
    }
}
