package com.akoval;

public class Parallelepiped extends Point3D {
    public Parallelepiped(int x, int y, int z) {
        super(x, y, z);
    }

    public int getVolume() {
        return getX()*getY()*getZ();
    }
}
