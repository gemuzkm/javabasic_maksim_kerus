package com.akoval.fruits;

public final class Apple extends Fruit {

    public Apple(double weight, double volume) {
        super(weight, volume);
    }

    @Override
    public int getTaste() {
        return 6;
    }
}
